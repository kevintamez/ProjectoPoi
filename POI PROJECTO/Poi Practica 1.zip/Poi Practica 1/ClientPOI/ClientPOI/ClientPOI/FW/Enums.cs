﻿
public enum UserState
{
    Connected,
    Absent,
    Busy
}
